//
//  ViewController.swift
//  App cuttin
//
//  Created by adithya on 9/11/19.
//  Copyright © 2019 adithya. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet var name: UITextField!
    @IBOutlet var email: UITextField!
    @IBOutlet var mobile: UITextField!
    
    @IBOutlet var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        name.layer.masksToBounds = false
        name.layer.shadowRadius = 3.0
        name.layer.shadowColor = UIColor.gray.cgColor
        name.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
        name.layer.shadowOpacity = 1.0
        
        email.layer.masksToBounds = false
        email.layer.shadowRadius = 3.0
        email.layer.shadowColor = UIColor.gray.cgColor
        email.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
        email.layer.shadowOpacity = 1.0
        
        mobile.layer.masksToBounds = false
        mobile.layer.shadowRadius = 3.0
        mobile.layer.shadowColor = UIColor.gray.cgColor
        mobile.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
        mobile.layer.shadowOpacity = 1.0
        
        password.layer.masksToBounds = false
        password.layer.shadowRadius = 3.0
        password.layer.shadowColor = UIColor.gray.cgColor
        password.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
        password.layer.shadowOpacity = 1.0
        
        
        let nameimg = UIImage(named:"user")
        addLeftImageTo(txtField: name, andImage: nameimg!)
        
        let emailimg = UIImage(named:"Email")
        addLeftImageTo(txtField: email, andImage: emailimg!)
        
        let mobileimg = UIImage(named:"mobile")
        addLeftImageTo(txtField: mobile, andImage: mobileimg!)
        
        let passwordimg = UIImage(named:"password")
        addLeftImageTo(txtField: password, andImage: passwordimg!)
    }
    func addLeftImageTo(txtField: UITextField, andImage img: UIImage) {
        let leftImageView = UIImageView(frame: CGRect(x: 0.0, y: 0.0, width: img.size.width, height: img.size.height))
        leftImageView.image = img
        txtField.rightView = leftImageView
        txtField.rightViewMode = .always
    }

}

